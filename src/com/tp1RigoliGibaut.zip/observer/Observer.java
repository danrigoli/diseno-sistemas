package com.observer;

public interface Observer {

    public double update(Product product);
}
