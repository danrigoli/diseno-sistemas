package com.flyweight;

public interface UnitFly {

    public void attack(String weapon);
    public void defend(String weapon);
    public int getTotalHealth();

}
