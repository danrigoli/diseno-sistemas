package com.decorator;

public interface MenuItem {
    String getDescription();
    int calculate();
}
