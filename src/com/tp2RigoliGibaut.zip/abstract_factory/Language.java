package com.abstract_factory;

public interface Language {

    public String getName();
    public void run();
}
