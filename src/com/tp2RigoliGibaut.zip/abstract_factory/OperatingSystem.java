package com.abstract_factory;

public interface OperatingSystem {

    public String getName();
    public void boot();
}
