package com.factory;

public interface Vehicle {
    public void start();
}
